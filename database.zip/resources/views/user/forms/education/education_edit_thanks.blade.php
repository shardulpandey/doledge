<div class="modal-dialog"> 
    <!-- Modal content-->
    <div class="modal-content">
    <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">{{__('Update Education')}}</h1>
        <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
      </div>
        <div class="modal-body">
            
                    <div class="userccount">
                        <div class="formpanel">
                            <div class="formrow">
                                <h3>{{__('Education Updated successfully')}}</h3>
                            </div>                
                        </div>            
                   
            </div>
        </div>
    </div>
</div>
