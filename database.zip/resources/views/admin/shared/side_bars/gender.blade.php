<li class="nav-item  "> <a href="javascript:;" class="nav-link nav-toggle"> <i class="fa fa-venus-double" aria-hidden="true"></i> <span class="title">Genders</span> <span class="arrow"></span> </a>
    <ul class="sub-menu">
        <li class="nav-item  "> <a href="{{ route('list.genders') }}" class="nav-link "> <span class="title">List Genders</span> </a> </li>
        <li class="nav-item  "> <a href="{{ route('create.gender') }}" class="nav-link "> <span class="title">Add new Gender</span> </a> </li>
        <li class="nav-item  "> <a href="{{ route('sort.genders') }}" class="nav-link "> <span class="title">Sort Genders</span> </a> </li>
    </ul>
</li>