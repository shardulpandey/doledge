<li class="nav-item  "> <a href="javascript:;" class="nav-link nav-toggle"> <i class="fa fa-globe" aria-hidden="true"></i> <span class="title">Cities</span> <span class="arrow"></span> </a>
    <ul class="sub-menu">
        <li class="nav-item  "> <a href="{{ route('list.cities') }}" class="nav-link "> <span class="title">List Cities</span> </a> </li>
        <li class="nav-item  "> <a href="{{ route('create.city') }}" class="nav-link "> <span class="title">Add new City</span> </a> </li>
    </ul>
</li>