<li class="nav-item  "> <a href="javascript:;" class="nav-link nav-toggle"> <i class="fa fa-money" aria-hidden="true"></i> <span class="title">Salary Periods</span> <span class="arrow"></span> </a>
    <ul class="sub-menu">
        <li class="nav-item  "> <a href="{{ route('list.salary.periods') }}" class="nav-link ">  <span class="title">List Salary Periods</span> </a> </li>
        <li class="nav-item  "> <a href="{{ route('create.salary.period') }}" class="nav-link ">  <span class="title">Add new Salary Period</span> </a> </li>
        <li class="nav-item  "> <a href="{{ route('sort.salary.periods') }}" class="nav-link "> <span class="title">Sort Salary Periods</span> </a> </li>
    </ul>
</li>