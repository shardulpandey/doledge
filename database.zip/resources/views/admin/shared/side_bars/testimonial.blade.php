<li class="nav-item  "> <a href="javascript:;" class="nav-link nav-toggle"> <i class="fa fa-file-text-o" aria-hidden="true"></i> <span class="title">Testimonials</span> <span class="arrow"></span> </a>
    <ul class="sub-menu">
        <li class="nav-item  "> <a href="{{ route('list.testimonials') }}" class="nav-link ">  <span class="title">List Testimonials</span> </a> </li>
        <li class="nav-item  "> <a href="{{ route('create.testimonial') }}" class="nav-link ">  <span class="title">Add new Testimonial</span> </a> </li>
        <li class="nav-item  "> <a href="{{ route('sort.testimonials') }}" class="nav-link "> <span class="title">Sort Testimonials</span> </a> </li>
    </ul>
</li>